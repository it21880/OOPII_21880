import java.util.ArrayList;

public interface PerceptronTraveller {
    ArrayList recommend();
    ArrayList recommend(boolean upper);
}
