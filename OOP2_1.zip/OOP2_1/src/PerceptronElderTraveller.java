import java.util.ArrayList;

public abstract class PerceptronElderTraveller implements PerceptronTraveller{

    public PerceptronElderTraveller() {
    }

    @Override
    public ArrayList recommend(boolean recom) {
        //return ArrayList of cities
        if (recom); /*return arraylist of cities UpperCased*/
        else ; //return arraylist of cities LowerCased
        return null;
    }
}
