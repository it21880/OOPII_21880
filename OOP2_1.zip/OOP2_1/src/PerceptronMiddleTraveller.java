import java.util.ArrayList;

public abstract class PerceptronMiddleTraveller implements PerceptronTraveller {

    public PerceptronMiddleTraveller() {
    }

    @Override
    public ArrayList recommend(boolean recom) {
        //return ArrayList of cities
        if (recom); /*return arraylist of cities UpperCased*/
        else ; //return arraylist of cities LowerCased
        return null;
    }
}
